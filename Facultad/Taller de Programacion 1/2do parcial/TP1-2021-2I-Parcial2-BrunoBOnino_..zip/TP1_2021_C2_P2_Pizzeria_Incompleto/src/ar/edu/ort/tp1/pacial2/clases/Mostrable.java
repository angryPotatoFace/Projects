package ar.edu.ort.tp1.pacial2.clases;

public interface Mostrable {
	void mostrar();
}
