package ar.edu.ort.tp1.pacial2.clases;

public class Pizzeria {

	private static final String MSG_PIZZA_TOPPINGS_NULO = "No se pudo fabricar Pizza o Topping nulo.";
	private static final String MSG_TOPPINGS = "Error de par�metros incorporando toppings";
	private static final String MSG_TOTALES = "La venta total fue: $%8.2f\n";
	private static final String MSG_CANTIDADES = "Se han fabricado: %d Tradicionales, %d Especiales y %d Rectangulares\n";

	public Pizzeria(String nombre) {
		// TODO A completar
	}

	public void incorporarTopping(TipoPizza tipoPizza, Topping topping, int cantidad) {
		// TODO A completar
	}

	public void ingresarPedido(Pizza p, Topping topping) {
		// TODO A completar
	}

}
