package tp1.parcial1.clases;
import java.util.ArrayList;

public class TallerMecanico {

/*	todo completar */	
	private ArrayList<Servicio> serviciosEfectuados;
	private String nombre;
	
	private static final String FORMATO_CANTIDADES = "Se efectuaron: %d cambios de aceite, %d encendido y %d alineacion\n";

	
	public TallerMecanico(String nombre) {
		//TODO A completar

	}
	
	public boolean agregarServicio(Servicio nuevoServicio) {
		boolean pudo = false;
		//TODO A completar

		return pudo;
	}
	
	public void listarServicios() {
		//TODO A completar
	}
}
