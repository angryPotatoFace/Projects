package tp1.parcial1.clases;

public class Alineacion extends Servicio implements CotizablePorManoObra {

	static final double EXTRABALANCEO = 500;
	
/*	todo completar */
	public Alineacion(String descripcion, double porcentajeGanancia,
			 String patente, int horas, boolean conBalanceo) {
	}
	

}
