package tp1.parcial1.clases;

public interface Detallable {

	public abstract void detallar();
	
	
}
