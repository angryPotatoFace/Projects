package tp1.parcial1.clases;

public class CambioAceite extends Servicio implements CotizablePorManoObra, CotizablePorMateriales {
	
/*	todo completar */	
	
	public CambioAceite(String descripcion, double porcentajeGanancia, String patente, int horas) {

	}

	

}
