package tp1.parcial1.clases;

public class Encendido extends Servicio implements CotizablePorMateriales {

/*	todo completar */	
	public Encendido(String descripcion, double porcentajeGanancia, String patente) {

	}
	
	

}
