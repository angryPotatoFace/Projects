package ar.edu.ort.tp1.recuperatorio.parte1.clases;

import java.util.ArrayList;

public class CentroBuceo {

	private static final int CANTIDAD_BUCEOS = 10;
	//TODO A completar atribuos.

	public CentroBuceo(String nombre) {
		//TODO A completar
	}

	/**
	 * Carga las reservas pasadas por par�metro en la estructura correspondiente del centro de buceo.
	 * @param reservas
	 */
	public void cargarReservas(ArrayList<Reserva> reservas) {
		// TODO A completar
		System.out.println("Se procesaron " + reservas.size() + " reservas");

	}

	public void mostrarEstadisticas() {
		System.out.println("Estadisticas del centro de buceo: " + nombre);

		this.mostrarCantidadDeReservasPorMes();
		this.mostrarPromedioDeReservasPorBuceo();

	}

	private void mostrarCantidadDeReservasPorMes() {
		// TODO A completar.

	}

	private void mostrarPromedioDeReservasPorBuceo() {
		// TODO A completar
	}

	public void mostrarCantidadMesesConReservasPorNombreBuceo(String nombreBuceo) {
		// TODO A completar
	}
	
	public void mostrarCantidadBuceosConReservasPorNombreMes(String nombreMes) {
		// TODO A completar
	}

}
