package ar.edu.ort.tp1.recuperatorio.parte2.clases;

/**
 * Buzo con autorizaci�n para bajar hasta los 30 metros inclusive. nunca puede realizar buceos mas profundos
 *
 */
public class BuzoAdvancedOpenWater extends Buzo {

	private static final int PROFUNDIDAD_MAXIMA_PERMITIDA = 30;

	public BuzoAdvancedOpenWater(String nombre, String nacionalidad, int edad) {
		//TODO A completar
	}

	//TODO A completar
}
