package ar.edu.ort.tp1.recuperatorio.parte2.clases;

/**
 * Buzo con autorizaci�n para bajar mas alla de los 30 metros.
 *
 */
public class BuzoTecnico extends Buzo {

	public BuzoTecnico(String nombre, String nacionalidad, int edad) {
		//TODO A completar
	}

	//TODO A completar

}
