package ar.edu.ort.tp1.examen.clases;

import ar.edu.ort.tp1.tdas.interfaces.ListaOrdenada;

public class Deposito implements Depositante<Producto, Integer> {

	private static final String MSG_TIPO_PROD_INVALIDO = "Tipo de producto inv�lido";
	private static final String MSG_NO_PUDO_DEPOSITAR = "No se pudo depositar el producto.";
	private static final String MSG_PROF_INVALIDO = "Profundidad de estanter�a inv�lido";
	private static final int ALTO_ESTANTERIA = 3;
	private static final int ANCHO_ESTANTERIA = 4;
	private static final int PROFUNDIDAD_ESTANTERIA_MAX = 10;
	private static final int PROFUNDIDAD_ESTANTERIA_MIN = 2;
	private static final int FILA_PELOTA = 0;
	private static final int FILA_RAQUETA = 1;
	private static final int FILA_BOLSO = 2;

	// TODO Completar

	// TODO Completar
	public Deposito(int profundidadEstanteria) {

	}


	// TODO Completar
	/**
	 * Deposita el producto recibido en la estanter�a, en la fila que le corresponde
	 * seg�n su producto, en el el primer estante que tenga lugar.
	 */
	
	/**
	 * Indica si un producto se encuentra depositado
	 * @param idProducto
	 * @return
	 */

	/**
	 * Retira un producto en base a su ID
	 */

}
