package ar.edu.ort.tp1.examen.clases;

public class Estante implements Depositante<Producto, Integer> {

	//TODO Completar

	public Estante(int profundidadEstanteria) {
	}

	/**
	 * Agrega un elemento al estante siempre y cuando haya lugar, sino, deber� emitir la excepci�n que corresponda..
	 */

	/**
	 * Retira el producto de la estanter�a por su id
	 */

}
