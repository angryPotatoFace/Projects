package ar.edu.ort.tp1.examen.clases;

public abstract class Producto implements Mostrable {
	private static final String MSG_MARCA_INVALIDA = "La marca no puede ser nula ni vac�a";
	private static final String MSG_ID_INVALIDO = "El id no puede ser menor a 1";
	//TODO Completar

	/**
	 * Constructor
	 * 
	 * @param id    debe ser mayor o igual a 1
	 * @param marca no ser nulo ni vac�o.
	 */
	public Producto(int id, String marca) {
	}
}
