package ar.edu.ort.tp1.examen.clases;

public class Bolso extends Producto {
	private static final String MODELO_DE_BOLSO_INV�LIDO = "Modelo de bolso inv�lido.";
	private static final String MSG_MODELO = 
			"El bolso es de modelo %s es de la marca %s y tiene un id %d\n";

	//TODO Completar

}
