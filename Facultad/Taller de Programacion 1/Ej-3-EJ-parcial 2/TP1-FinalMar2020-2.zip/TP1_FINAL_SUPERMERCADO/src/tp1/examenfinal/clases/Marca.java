package tp1.examenfinal.clases;
//TODO COMPLETAR
public class Marca {

	private static final String MSG_ORIGEN_INVALIDO = "Origen de la marca inv�lida";
	private static final String MSG_NOMBRE_INVALIDO = "Nombre de la marca inv�lido";
	// TODO COMPLETAR

}
