package tp1.examenfinal.clases;
//TODO COMPLETAR
public abstract class Producto {

	private static final String MSG_NOMBRE_INVALIDO = "Nombre del producto inv�lido";
	private static final String MSG_DESCRIPCION_INVALIDO = "Descripci�n del producto inv�lido";
	private static final String MSG_ID_INVALIDO = "ID del producto inv�lido";

	//TODO COMPLETAR

}
