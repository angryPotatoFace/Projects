package tp1.examenfinal.clases;

import java.util.ArrayList;

import tp1.examenfinal.tad.Cola;
import tp1.examenfinal.tad.Pila;
import tp1.examenfinal.tad.implementaciones.arraylist.ColaAL;
import tp1.examenfinal.tad.implementaciones.arraylist.PilaAL;

public class MarketOnline {

	private static final String MSG_PROD_NO_ENCONTRADO = "Producto no encontrado";
	private static final String MSG_CANT_PRODS_INVALIDA = "La cantidad de productos indicada es erronea";
	private static final String MSG_NOMBRE_INVALIDO = "El nombre del mercado es invalido";
	private static final int CANT_PRODS_MINIMO = 5;
	private static final int CANT_PRODS_MAXIMO = 30;

//	TODO COMPLETAR

}
