package tp1.examenfinal.clases;

public class ProductoSimple {

	private static final String TXT_MOSTRAR = "Ordenando el producto %s, Descripci�n: %s, con marca %s\n";

	//TODO COMPLETAR

}
