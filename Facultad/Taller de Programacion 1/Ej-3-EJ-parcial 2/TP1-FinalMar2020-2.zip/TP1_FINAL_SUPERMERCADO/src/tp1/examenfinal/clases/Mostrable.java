package tp1.examenfinal.clases;

public interface Mostrable {

	//TODO COMPLETAR
}
