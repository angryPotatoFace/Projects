package tp1.examenfinal.clases;

public interface Pedible {
	//TODO COMPLETAR
}
