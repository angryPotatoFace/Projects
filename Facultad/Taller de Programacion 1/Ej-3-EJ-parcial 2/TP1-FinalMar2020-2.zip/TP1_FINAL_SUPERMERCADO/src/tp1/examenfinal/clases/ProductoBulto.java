package tp1.examenfinal.clases;
//TODO COMPLETAR
public class ProductoBulto {

	private static final String TXT_MOSTRAR = "Ordenando las %d unidades del producto %s, Descripci�n: %s, con marca %s\n";
	private int cantidadXBulto;

	//TODO COMPLETAR
}
