package ar.edu.ort.tp1.parcial2.clases;

public interface Listable {
	void listar();
}
