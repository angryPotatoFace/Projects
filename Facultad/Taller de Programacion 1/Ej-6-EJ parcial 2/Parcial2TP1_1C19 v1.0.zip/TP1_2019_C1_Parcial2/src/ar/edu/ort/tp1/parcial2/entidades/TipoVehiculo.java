/**
 * 
 */
package ar.edu.ort.tp1.parcial2.entidades;

/**
 * Tipos de veh�culo
 * 
 * @author Julio Sejtman
 *
 */
public enum TipoVehiculo {
	AUTO, MOTOCICLETA
}
