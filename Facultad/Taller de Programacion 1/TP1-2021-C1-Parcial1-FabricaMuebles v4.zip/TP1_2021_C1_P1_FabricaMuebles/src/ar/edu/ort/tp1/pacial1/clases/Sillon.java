package ar.edu.ort.tp1.pacial1.clases;

public class Sillon extends Mueble {

	//TODO A completar


}
