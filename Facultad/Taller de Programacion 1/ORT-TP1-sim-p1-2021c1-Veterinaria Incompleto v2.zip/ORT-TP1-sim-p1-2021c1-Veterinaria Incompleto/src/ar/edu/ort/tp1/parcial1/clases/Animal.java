package ar.edu.ort.tp1.parcial1.clases;

public interface Animal {
	
	public void comer(double comida);

	public void defecar();
}
