package ar.edu.ort.tp1.parcial1.clases;

import java.util.ArrayList;

public class Veterinaria implements Mostrable {

	private static final String TXT_INGRESO = "Ingresando a %s a la veterinaria \n";
	private static final String TXT_CANTIDADES = "Han sido ingresados: %d conejos, %d gatos y %d perros\n";
	// TODO A completar

	public Veterinaria(String nombre, Doctor doctor) {
		// TODO A completar
	}

	public void admitirMascota(Mascota mascota) {
		// TODO A completar
	}

	public Mascota buscarMascota(String nombreDeMascota) {
		// TODO A completar
	}

	public void vacunar() {
		// TODO A completar
	}

}
