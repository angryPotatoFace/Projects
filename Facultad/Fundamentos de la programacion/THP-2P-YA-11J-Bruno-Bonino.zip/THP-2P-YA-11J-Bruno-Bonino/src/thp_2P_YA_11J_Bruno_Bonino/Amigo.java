package thp_2P_YA_11J_Bruno_Bonino;

public class Amigo {
	
	private Socio socio;

	public Amigo(Socio socio) {
		this.socio = socio;
	}
	
	public void mostrarDatos(){
		System.out.println("Datos Amigo");
		System.out.println("Nombre : "+socio.getNombre());
		System.out.println("Edad : "+socio.getEdad());
	}

	public Socio getSocio() {
		return socio;
	}

	private void setSocio(Socio socio) {
		if(socio!=null) {
			this.socio = socio;
		}
	}
	
	public double obtenerEdad(){
		return socio.getEdad();
	}
	
	public String obtenerNombre(){
		return socio.getNombre();
	}

}
