package thp_2P_YA_11J_Bruno_Bonino;
import java.util.ArrayList;
import java.util.Iterator;

public class Socio {

	private String nombre;
	private double edad;
	private ArrayList<Amigo>amigos;
	
	public Socio(String nombre, double edad){
		
		setNombre(nombre);
		setEdad(edad);
		this.amigos=new ArrayList<Amigo>();
	}
	
	
	private Amigo buscarAmigo(Amigo amigo) {
		Amigo resultado=null;
		int i=0;
		while(i<this.amigos.size() && resultado==null){
			if(this.amigos.get(i)==amigo){
				resultado = this.amigos.get(i);
			}else {
				i++;
			}
		}
		return resultado;
	}
	
	
	public Amigo buscarAmigo(String nombre) {
		Amigo resultado=null;
		int i=0;
		while(i<this.amigos.size() && resultado==null){
			if(this.amigos.get(i).obtenerNombre()==nombre){
				resultado = amigos.get(i);
			}else {
				i++;
			}
		}
		return resultado;
	}
	
	
	
	public void agregarAmigo(Socio socio){
		if(socio.getNombre()!=this.nombre){
			amigos.add(new Amigo(socio));
		}
	}
	
	public boolean deshacerAmistad(String nombre){
		boolean resultado=false;
		int i=0;
		while(i<this.amigos.size() && resultado==false){
			if(this.amigos.get(i).obtenerNombre()==nombre){
				resultado=true;
				this.amigos.remove(i);
			}else {
				i++;
			}
		}
		return resultado;
	}
	
	public String nombreAmigoMasJoven() {
		String resultado=null;
		double max=99999;
		for (Amigo amigo : amigos) {
			if(amigo.obtenerEdad()<max){
				max=amigo.obtenerEdad();
				resultado=amigo.obtenerNombre();
			}
		}
		return resultado;
	}
	
	public void mostrarAmigos() {
		for (Amigo amigo : amigos){
			amigo.mostrarDatos();
		}
	}
	
	//------------------Setters and Getters--------------------------

	public String getNombre(){
		return nombre;
	}

	private void setNombre(String nombre) {
		if(nombre!=null) {
		this.nombre = nombre;
		}
		
	}

	public double getEdad() {
		return edad;
	}

	private void setEdad(double edad) {
		if(edad>1 && edad<100){
			this.edad = edad;
		}
	}

}
