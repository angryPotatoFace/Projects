package thp_2P_YA_11J_Bruno_Bonino;

public class SocioYAmigo {
	
	private Socio socio;
	private String nombreAmigoJoven;
	
	public SocioYAmigo(Socio socio, String nombreAmigoJoven) {

		this.socio = socio;
		this.nombreAmigoJoven = nombreAmigoJoven;
	}

}
