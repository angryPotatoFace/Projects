package thp_2P_YA_11J_Bruno_Bonino;

public class Test {

	public static void main(String[] args) {
		Club club = new Club("Club Amigos");
		System.out.println(club.agregarSocio("Juan",23));
		System.out.println(club.agregarSocio("Laura",18));
		System.out.println(club.agregarSocio("Maria",26));
		System.out.println(club.agregarSocio("Joaquin",20));
		System.out.println(club.agregarSocio("Belen",20));
		System.out.println(club.agregarSocio("Daniel",21));
		System.out.println(club.agregarSocio("Valeria",20));
		System.out.println(club.agregarSocio("Ana",19));
		System.out.println(club.agregarSocio("Javier",22));
		System.out.println(club.agregarSocio("Javier",22));
		
		System.out.println("----------------------------------------------------------");
		
		System.out.println(club.amistarSocios("Juan","Ana"));
		System.out.println(club.amistarSocios("Laura","Ana"));
		System.out.println(club.amistarSocios("Laura","Juan"));
		System.out.println(club.amistarSocios("Maria","Ana"));
		System.out.println(club.amistarSocios("Belen","Joaquin"));
		System.out.println(club.amistarSocios("Belen","Daniel"));
		System.out.println(club.amistarSocios("Valeria","Ana"));
		System.out.println(club.amistarSocios("Ana","Daniel"));
		System.out.println(club.amistarSocios("Javier","Juan"));
		System.out.println(club.amistarSocios("Javier","Ana"));
		System.out.println(club.amistarSocios("Ana","Javier"));
		System.out.println(club.amistarSocios("Ana","Ana"));
		System.out.println(club.amistarSocios("Laura","Marcelo"));
		System.out.println(club.amistarSocios("Toribio","Ana"));
		
		System.out.println("----------------------------------------------------------");

		

		System.out.println(club.deshacerAmistad("Ana","Javier"));
		System.out.println(club.deshacerAmistad("Ana","Valeria"));
		System.out.println(club.deshacerAmistad("Josefina","Josefina"));
		System.out.println(club.deshacerAmistad("Laura","Marcelo"));

		club.mostrarAmigos("Laura");
		club.mostrarAmigos("Walter");


	}

}
