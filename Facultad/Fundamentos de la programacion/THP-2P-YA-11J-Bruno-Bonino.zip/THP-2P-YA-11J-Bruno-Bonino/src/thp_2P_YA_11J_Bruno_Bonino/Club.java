package thp_2P_YA_11J_Bruno_Bonino;
import java.util.ArrayList;


public class Club {
	
	private String nombre;
	private ArrayList<Socio>socios;
	
	public Club(String nombre) {
		setNombre(nombre);
		this.socios=new ArrayList<Socio>();
	}
	
	public Resultado agregarSocio(String nombre, double edad){
		Resultado resultado=null;
		if(nombre!=null){
			if(edad>1 && edad<100){
				if(buscarSocio(nombre)==null){
					this.socios.add(new Socio(nombre, edad));
					resultado=Resultado.OK;
				}else {
					resultado=Resultado.YA_EXISTE;
				}
			}else {
				resultado=Resultado.DATOS_INVALIDOS;
			}
		}else {
			resultado=Resultado.DATOS_INVALIDOS;
		}
		return resultado;
	}
	private Socio buscarSocio(String nombre1) {
		Socio resultado=null;
		int i=0;
		while(i<this.socios.size() && resultado==null){
			if(this.socios.get(i).getNombre()==nombre1){
				resultado=this.socios.get(i);
			}else {
				i++;
			}
		}
		return resultado;
	}
	
	public Resultado amistarSocios(String nombre1,String nombre2){
		Resultado resultado=null;
		Socio socio1;
		Socio socio2;
		if(validarNombres(nombre1,nombre2)) {
			socio1=buscarSocio(nombre1);
			if(socio1!=null){
				socio2=buscarSocio(nombre2);
				if(socio2!=null){
					if(nombre1!=nombre2) {
						if(socio1.buscarAmigo(nombre2)==null ) {
						socio1.agregarAmigo(socio2);
						socio2.agregarAmigo(socio1);
						resultado=Resultado.OK;
						}else {
							resultado=Resultado.YA_SON_AMIGOS;
						}
					}else {
						resultado=Resultado.MISMA_PERSONA;
					}
				}else {
					resultado=Resultado.PERSONA_NO_ES_SOCIO;
				}
			}else {
				resultado=Resultado.PERSONA_NO_ES_SOCIO;
			}
		}else {
			resultado=Resultado.DATOS_INVALIDOS;
		}
		return resultado;
	}
	
	private boolean validarNombres(String nombre1,String nombre2){
		boolean resultado=false;
		if(nombre1 != null && nombre2 !=null) {
			resultado=true;
		}
		return resultado;
	}
	

	public Resultado deshacerAmistad(String socio1,String amigo1){
		Resultado resultado=null;
		
		if(socio1!=null){
					if(amigo1!=null){
							if(socio1!=amigo1){
								Socio socio=buscarSocio(socio1);
								Socio socio2=buscarSocio(amigo1);
								Amigo amigo=socio.buscarAmigo(amigo1);
								if(socio!=null && socio2!=null){
										if(socio.deshacerAmistad(amigo1)){
											socio.deshacerAmistad(amigo1);
											socio2.deshacerAmistad(socio1);
											resultado=Resultado.AMISTAD_DESHECHA;
										}else {
											resultado=Resultado.NO_ERAN_AMIGOS;
										}
									}else{
										resultado=Resultado.NO_EXISTE;
									}
							}else {
								resultado=Resultado.MISMA_PERSONA;
							}
					}else {
						resultado=Resultado.DATOS_INVALIDOS;
					}
		}else {
			resultado=Resultado.DATOS_INVALIDOS;
		}
		return resultado;
	}
	
	public ArrayList<SocioYAmigo> listarSociosConAmigo(){
		ArrayList<SocioYAmigo> lista=new ArrayList<SocioYAmigo>();
		for (Socio socio : socios) {
			if(socio.nombreAmigoMasJoven()!=null){
				lista.add(new SocioYAmigo(socio, nombre));
			}
		}
		return lista;
	}
	
	public void mostrarAmigos(String nombre){
		Socio socio = buscarSocio(nombre);
		if(socio!=null) {
			System.out.println("Nombre Socio :"+socio.getNombre());
			socio.mostrarAmigos();
		}else {
			System.out.println("No hay nadie llamado "+nombre);
		}
	}
	
	//--------------------- Setters and Getters --------------------------------------------
	private String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		if(nombre != null) {
			this.nombre = nombre;
		}
	}

	private ArrayList<Socio> getSocio() {
		return socios;
	}

	private void setSocio(ArrayList<Socio> socio) {
		this.socios = socio;
	}
	
	
	
}
